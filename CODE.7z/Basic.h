#ifndef _BASIC_H
#define _BASIC_H

#include <cstring>
#include <algorithm>
#include <sstream>

enum Compress_Method {
	Sum_Selection, Max_Selectionp, Hierarchical
};

#endif
